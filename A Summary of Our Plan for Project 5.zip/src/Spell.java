public class Spell {

  //hopefully this pushes now
    private String name;
  private int damage;
  private int slotLevel;

  /**
   * constructs a spell
   * @param name name of spell
   * @param damage spell damage
   * @param slotLevel level of spell
   */
  public Spell(String name, int damage, int slotLevel){

  }



}
